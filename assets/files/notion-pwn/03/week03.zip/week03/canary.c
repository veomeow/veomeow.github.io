// gcc canary.c -o canary -no-pie

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void init() {
  setvbuf(stdin, 0, 2, 0);
  setvbuf(stdout, 0, 2, 0);
}

void win() {
  execve("/bin/sh", NULL, NULL);
}

int main() {
  init();
  char buf[0x28];

  for (int i = 0; i < 2; i++) {
    printf("Input something: ");
    read(0, buf, 0x100);
    printf("buf: %s\n", buf);
  }

  return 0;
}