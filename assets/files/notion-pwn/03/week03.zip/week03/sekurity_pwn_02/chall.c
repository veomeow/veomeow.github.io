// gcc chall.c -o chall -fno-stack-protector -no-pie

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

void init() {
  setvbuf(stdin, 0, 2, 0);
  setvbuf(stdout, 0, 2, 0);
}

void admin() {
  int fd;
  char flag[40] = { 0, };
  fd = open("./flag", O_RDONLY);
  read(fd, flag, 40);

  printf("flag: %s\n", flag);
  exit(0);
}

int main() {
  init();

  char name[0x10];
  int is_admin = 0;

  write(1, "Your name: ", 11);
  read(0, name, 100);

  if (is_admin) {
    printf("Welcome my admin!\n");
    admin();
  } else {
    printf("Who are you?\n");
  }

  return 0;
}