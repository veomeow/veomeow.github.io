// gcc -o chall chall.c -fno-stack-protector -fno-pie -no-pie

#include <stdio.h>
#include <string.h>

void init() {
  setvbuf(stdin, 0, 2, 0);
  setvbuf(stdout, 0, 2, 0);
}

int main() {
  char str[9] = { 0 };
  int number = 0x123;

  init();

  printf("Please Type [seKUrity]\n");
  printf("> ");
  scanf("%8s", str);

  printf("Your Input: %s\n", str);
  if (strncmp(str, "seKUrity", 8) == 0) {
    printf("Success!\n");
  } else {
    printf("Failed!\n");
  }
}