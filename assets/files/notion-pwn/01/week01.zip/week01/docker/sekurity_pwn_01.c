// gcc -o sekurity_pwn_01 sekurity_pwn_01.c -fno-stack-protector

#include <stdio.h>
#include <string.h>

void init() {
  setvbuf(stdin, 0, 2, 0);
  setvbuf(stdout, 0, 2, 0);
}

int main() {
  char str[9] = { 0 };

  init();

  printf("Please Type [seKUUUrity]\n");
  printf("> ");
  scanf("%10s", str);

  printf("Your Input: %s\n", str);
  if (strncmp(str, "seKUUUrity", 10) == 0) {
    printf("Success!\n");
  } else {
    printf("Failed!\n");
  }
}